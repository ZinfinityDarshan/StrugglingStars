import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import {RegisterPage} from '../pages/register/register.page'

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'searchtab',
        children: [
          {
            path: '',
            loadChildren: './search/search.module#SearchPageModule'
          }
        ]
      },
      {
        path: 'trendingtab',
        children: [
          {
            path: '',
            loadChildren: './trending/trending.module#TrendingPageModule'
          }
        ]
      },
      {
        path: 'acounttab',
        children: [
          {
            path: '',
            loadChildren: './acount/account.module#AccountPageModule'
          }
        ]
      },
      {
        path: 'home',
        children: [
          {
            path: '',
            loadChildren: './hometab/hometab.module#HometabPageModule'
          }
        ]
      },
      {
        path: 'register',
        children: [
          {
            path: '',
            loadChildren: '../pages/register/register.module#RegisterPageModule'
          }
        ]
      },
      {
        path: '',
        redirectTo: '/tabs/register',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/register',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
