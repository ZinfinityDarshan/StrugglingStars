(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["acount-account-module"],{

/***/ "./src/app/tabs/acount/account.module.ts":
/*!***********************************************!*\
  !*** ./src/app/tabs/acount/account.module.ts ***!
  \***********************************************/
/*! exports provided: AccountPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountPageModule", function() { return AccountPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _account_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./account.page */ "./src/app/tabs/acount/account.page.ts");







var routes = [
    {
        path: '',
        component: _account_page__WEBPACK_IMPORTED_MODULE_6__["AccountPage"]
    }
];
var AccountPageModule = /** @class */ (function () {
    function AccountPageModule() {
    }
    AccountPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_account_page__WEBPACK_IMPORTED_MODULE_6__["AccountPage"]]
        })
    ], AccountPageModule);
    return AccountPageModule;
}());



/***/ }),

/***/ "./src/app/tabs/acount/account.page.html":
/*!***********************************************!*\
  !*** ./src/app/tabs/acount/account.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\">\n    <div class=\"name\">ActorName</div>\n  </div>\n  \n  <ion-content>\n    <div class=\"profilepart\">\n      <div class=\"profile\">\n        <div class=\"profilephoto\"></div>\n        <div class=\"profilename\">Actor 1</div>\n      </div>\n      <div class=\"follows\">\n        <div class=\"number\">\n          <p>0</p>\n          <p>Posts</p>\n        </div>\n        <div class=\"number\">\n          <p>0</p>\n          <p>Followers</p>\n        </div>\n        <div class=\"number\">\n          <p>0</p>\n          <p>Following</p>\n        </div>\n      </div>\n    </div>\n    <div class=\"bio\">\n      <ion-card>\n        <ion-card-header>\n          <ion-card-title>Bio</ion-card-title>\n        </ion-card-header>\n      \n        <ion-card-content>\n          Keep close to Nature's heart... and break clear away, once in awhile,\n          and climb a mountain or spend a week in the woods. Wash your spirit clean.\n        </ion-card-content>\n      </ion-card>\n    </div>\n    <div class=\"tabs\">\n      <div class=\"tab\" (click)=\"enable('image')\">\n        <ion-button fill=\"clear\" [class.active]=\"showimage\"><ion-icon name=\"image\"></ion-icon></ion-button>\n      </div>\n      <div class=\"tab\" (click)=\"enable('video')\">\n        <ion-button fill=\"clear\" [class.active]=\"showvideo\"><ion-icon name=\"videocam\"></ion-icon></ion-button>\n      </div>\n      <div class=\"tab\" (click)=\"enable('document')\">\n        <ion-button fill=\"clear\" [class.active]=\"showdocument\"><ion-icon name=\"document\"></ion-icon></ion-button>\n      </div>\n    </div>\n  \n    <div class=\"content\">\n      <div class=\"images\" *ngIf=\"showimage\">\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n        <div class=\"img\"></div>\n      </div>\n      <div class=\"videos\" *ngIf=\"showvideo\">\n        <div class=\"video\"></div>\n        <div class=\"video\"></div>\n        <div class=\"video\"></div>\n        <div class=\"video\"></div>\n        <div class=\"video\"></div>\n        <div class=\"video\"></div>\n      </div>\n      <div class=\"document\" *ngIf=\"showdocument\">\n        Document\n      </div>\n    </div>\n  </ion-content>\n  "

/***/ }),

/***/ "./src/app/tabs/acount/account.page.scss":
/*!***********************************************!*\
  !*** ./src/app/tabs/acount/account.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n  font-size: 1.2rem;\n  width: 100%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  border-bottom: 1px solid gainsboro; }\n\n.profilepart {\n  display: flex;\n  padding: 10px;\n  border-bottom: 1px solid gainsboro; }\n\n.profilepart .profile {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    width: 30vw; }\n\n.profilepart .profile .profilephoto {\n      width: 80px;\n      height: 80px;\n      border-radius: 40px;\n      background: red;\n      margin-bottom: 10px; }\n\n.profilepart .follows {\n    width: 70vw;\n    display: flex;\n    justify-content: space-around; }\n\n.profilepart .follows .number {\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n      width: 80px; }\n\n.profilepart .follows .number p {\n        margin: 10px;\n        font-size: .8rem; }\n\n.bio {\n  border-bottom: 1px solid gainsboro; }\n\n.tabs {\n  display: flex;\n  justify-content: space-around;\n  border-bottom: 1px solid gainsboro; }\n\n.tabs .tab {\n    display: flex;\n    justify-content: center;\n    align-items: center; }\n\n.tabs .tab ion-button {\n      font-size: 1.1rem;\n      margin: 0;\n      height: 70px;\n      width: 70px;\n      color: black; }\n\n.tabs .tab .active {\n      color: #3880ff; }\n\n.content .images {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center; }\n\n.content .images .img {\n    width: 120px;\n    height: 120px;\n    background: coral;\n    margin: 5px; }\n\n.content .videos {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center; }\n\n.content .videos .video {\n    width: 120px;\n    height: 120px;\n    background: greenyellow;\n    margin: 5px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFicy9hY291bnQvRTpcXE1heXVyX0FjYzAwOFxcY29kZVxcZnJvbnRlbmRcXG1vYmlsZVxcc3Rhci9zcmNcXGFwcFxcdGFic1xcYWNvdW50XFxhY2NvdW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQWE7RUFDYiw4QkFBOEI7RUFDOUIsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixXQUFXO0VBQ1gsMkJBQW1CO0VBQW5CLHdCQUFtQjtFQUFuQixtQkFBbUI7RUFDbkIsa0NBQWtDLEVBQUE7O0FBR3BDO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixrQ0FBa0MsRUFBQTs7QUFIcEM7SUFNSSxhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLG1CQUFtQjtJQUNuQixXQUFXLEVBQUE7O0FBVGY7TUFZTSxXQUFXO01BQ1gsWUFBWTtNQUNaLG1CQUFtQjtNQUNuQixlQUFlO01BQ2YsbUJBQW1CLEVBQUE7O0FBaEJ6QjtJQXFCSSxXQUFXO0lBQ1gsYUFBYTtJQUNiLDZCQUE2QixFQUFBOztBQXZCakM7TUEwQk0sYUFBYTtNQUNiLHNCQUFzQjtNQUN0QixtQkFBbUI7TUFDbkIsV0FBVyxFQUFBOztBQTdCakI7UUFpQ1EsWUFBWTtRQUNaLGdCQUFnQixFQUFBOztBQU14QjtFQUNFLGtDQUFrQyxFQUFBOztBQUdwQztFQUNFLGFBQWE7RUFDYiw2QkFBNkI7RUFDN0Isa0NBQWtDLEVBQUE7O0FBSHBDO0lBTUksYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUIsRUFBQTs7QUFSdkI7TUFXTSxpQkFBaUI7TUFDakIsU0FBUztNQUNULFlBQVk7TUFDWixXQUFXO01BQ1gsWUFBWSxFQUFBOztBQWZsQjtNQW1CTSxjQUFjLEVBQUE7O0FBS3BCO0VBSUksYUFBYTtFQUNiLGVBQWU7RUFDZix1QkFBdUIsRUFBQTs7QUFOM0I7SUFTTSxZQUFZO0lBQ1osYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixXQUFXLEVBQUE7O0FBWmpCO0VBaUJJLGFBQWE7RUFDYixlQUFlO0VBQ2YsdUJBQXVCLEVBQUE7O0FBbkIzQjtJQXNCTSxZQUFZO0lBQ1osYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWJzL2Fjb3VudC9hY2NvdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIHBhZGRpbmc6IDEwcHggMjBweDtcclxuICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IGZpdC1jb250ZW50O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICB9XHJcbiAgXHJcbiAgLnByb2ZpbGVwYXJ0IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICAgIFxyXG4gICAgLnByb2ZpbGUge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICB3aWR0aDogMzB2dztcclxuICBcclxuICAgICAgLnByb2ZpbGVwaG90byB7XHJcbiAgICAgICAgd2lkdGg6IDgwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDQwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogcmVkO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICBcclxuICAgIC5mb2xsb3dzIHtcclxuICAgICAgd2lkdGg6IDcwdnc7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gIFxyXG4gICAgICAubnVtYmVyIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICB3aWR0aDogODBweDtcclxuICBcclxuICBcclxuICAgICAgICBwIHtcclxuICAgICAgICAgIG1hcmdpbjogMTBweDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIC5iaW8ge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICB9XHJcbiAgXHJcbiAgLnRhYnMge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICBcclxuICAgIC50YWIge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBcclxuICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxLjFyZW07XHJcbiAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIGhlaWdodDogNzBweDtcclxuICAgICAgICB3aWR0aDogNzBweDtcclxuICAgICAgICBjb2xvcjogYmxhY2s7IFxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICAuYWN0aXZlIHtcclxuICAgICAgICBjb2xvcjogIzM4ODBmZjtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAuY29udGVudCB7XHJcbiAgICAvLyBwYWRkaW5nOiAxMHB4O1xyXG4gIFxyXG4gICAgLmltYWdlcyB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgXHJcbiAgICAgIC5pbWcge1xyXG4gICAgICAgIHdpZHRoOiAxMjBweDtcclxuICAgICAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6IGNvcmFsO1xyXG4gICAgICAgIG1hcmdpbjogNXB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgXHJcbiAgICAudmlkZW9zIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC13cmFwOiB3cmFwO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgXHJcbiAgICAgIC52aWRlbyB7XHJcbiAgICAgICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgICAgIGhlaWdodDogMTIwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogZ3JlZW55ZWxsb3c7XHJcbiAgICAgICAgbWFyZ2luOiA1cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9Il19 */"

/***/ }),

/***/ "./src/app/tabs/acount/account.page.ts":
/*!*********************************************!*\
  !*** ./src/app/tabs/acount/account.page.ts ***!
  \*********************************************/
/*! exports provided: AccountPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountPage", function() { return AccountPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AccountPage = /** @class */ (function () {
    function AccountPage() {
        this.showimage = true;
        this.showvideo = false;
        this.showdocument = false;
    }
    AccountPage.prototype.ngOnInit = function () {
    };
    AccountPage.prototype.enable = function (name) {
        if (name === 'image') {
            this.showimage = true;
            this.showdocument = false;
            this.showvideo = false;
        }
        else if (name === 'video') {
            this.showimage = false;
            this.showdocument = false;
            this.showvideo = true;
        }
        else if (name === 'document') {
            this.showimage = false;
            this.showdocument = true;
            this.showvideo = false;
        }
    };
    AccountPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-account',
            template: __webpack_require__(/*! ./account.page.html */ "./src/app/tabs/acount/account.page.html"),
            styles: [__webpack_require__(/*! ./account.page.scss */ "./src/app/tabs/acount/account.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AccountPage);
    return AccountPage;
}());



/***/ })

}]);
//# sourceMappingURL=acount-account-module.js.map