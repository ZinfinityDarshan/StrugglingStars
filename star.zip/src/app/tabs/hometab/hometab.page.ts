import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hometab',
  templateUrl: './hometab.page.html',
  styleUrls: ['./hometab.page.scss'],
})
export class HometabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
