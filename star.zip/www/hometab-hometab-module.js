(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["hometab-hometab-module"],{

/***/ "./src/app/tabs/hometab/hometab.module.ts":
/*!************************************************!*\
  !*** ./src/app/tabs/hometab/hometab.module.ts ***!
  \************************************************/
/*! exports provided: HometabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HometabPageModule", function() { return HometabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _hometab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./hometab.page */ "./src/app/tabs/hometab/hometab.page.ts");







var routes = [
    {
        path: '',
        component: _hometab_page__WEBPACK_IMPORTED_MODULE_6__["HometabPage"]
    }
];
var HometabPageModule = /** @class */ (function () {
    function HometabPageModule() {
    }
    HometabPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_hometab_page__WEBPACK_IMPORTED_MODULE_6__["HometabPage"]]
        })
    ], HometabPageModule);
    return HometabPageModule;
}());



/***/ }),

/***/ "./src/app/tabs/hometab/hometab.page.html":
/*!************************************************!*\
  !*** ./src/app/tabs/hometab/hometab.page.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"header\">\n    <div class=\"brand\">Home</div>\n  </div>\n  \n  <ion-content>\n    <div class=\"posts\">\n      <ion-card>\n        <ion-card-header>\n          <ion-card-title>Card Title</ion-card-title>\n        </ion-card-header>\n        <div class=\"image\">\n          \n        </div>\n        <ion-card-content>\n          <div class=\"buttons\">\n            <ion-icon name=\"heart\"></ion-icon>\n            <ion-icon name=\"chatbubbles\"></ion-icon>\n          </div>\n  \n          <div class=\"comment\">\n            <a href=\"#\">View All 6 Comments</a>\n            <div class=\"addcomment\">\n              <input type=\"text\" placeholder=\"Add a comment...\">\n              <ion-button fill=\"clear\">Post</ion-button>\n            </div>\n          </div>\n        </ion-card-content>\n      </ion-card> \n  \n  \n      <ion-card>\n        <ion-card-header>\n          <ion-card-title>Card Title</ion-card-title>\n        </ion-card-header>\n        <div class=\"image\">\n          \n        </div>\n        <ion-card-content>\n          <div class=\"buttons\">\n            <ion-icon name=\"heart\"></ion-icon>\n            <ion-icon name=\"chatbubbles\"></ion-icon>\n          </div>\n  \n          <div class=\"comment\">\n            <a href=\"#\">View All 6 Comments</a>\n            <div class=\"addcomment\">\n              <input type=\"text\" placeholder=\"Add a comment...\">\n              <ion-button fill=\"clear\">Post</ion-button>\n            </div>\n          </div>\n        </ion-card-content>\n      </ion-card> \n  \n  \n      <ion-card>\n        <ion-card-header>\n          <ion-card-title>Card Title</ion-card-title>\n        </ion-card-header>\n        <div class=\"image\">\n          \n        </div>\n        <ion-card-content>\n          <div class=\"buttons\">\n            <ion-icon name=\"heart\"></ion-icon>\n            <ion-icon name=\"chatbubbles\"></ion-icon>\n          </div>\n  \n          <div class=\"comment\">\n            <a href=\"#\">View All 6 Comments</a>\n            <div class=\"addcomment\">\n              <input type=\"text\" placeholder=\"Add a comment...\">\n              <ion-button fill=\"clear\">Post</ion-button>\n            </div>\n          </div>\n        </ion-card-content>\n      </ion-card> \n    </div>     \n  </ion-content>\n  \n  "

/***/ }),

/***/ "./src/app/tabs/hometab/hometab.page.scss":
/*!************************************************!*\
  !*** ./src/app/tabs/hometab/hometab.page.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".header {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n  font-size: 1.2rem;\n  width: 100%;\n  height: -webkit-fit-content;\n  height: -moz-fit-content;\n  height: fit-content;\n  border-bottom: 1px solid gainsboro; }\n\n.posts ion-card {\n  margin-bottom: 25px; }\n\n.posts ion-card .image {\n    width: 100%;\n    height: 250px;\n    background: cornflowerblue; }\n\n.posts ion-card ion-card-content .buttons ion-icon {\n    font-size: 1rem;\n    padding-right: 10px; }\n\n.posts ion-card ion-card-content .comment a {\n    color: gray;\n    text-decoration: none;\n    font-size: .8rem;\n    margin-top: 10px; }\n\n.posts ion-card ion-card-content .comment .addcomment {\n    display: flex;\n    width: 100%;\n    padding: 0 10px;\n    margin-top: 10px;\n    border-top: 1px solid gainsboro; }\n\n.posts ion-card ion-card-content .comment .addcomment input {\n      width: 80vw;\n      border: none; }\n\n.posts ion-card ion-card-content .comment .addcomment input::-webkit-input-placeholder {\n        color: silver; }\n\n.posts ion-card ion-card-content .comment .addcomment input::-moz-placeholder {\n        color: silver; }\n\n.posts ion-card ion-card-content .comment .addcomment input:-ms-input-placeholder {\n        color: silver; }\n\n.posts ion-card ion-card-content .comment .addcomment input::-ms-input-placeholder {\n        color: silver; }\n\n.posts ion-card ion-card-content .comment .addcomment input::placeholder {\n        color: silver; }\n\n.posts ion-card ion-card-content .comment .addcomment input:focus {\n        outline: none; }\n\n.posts ion-card ion-card-content .comment .addcomment ion-button {\n      width: 20vw; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFicy9ob21ldGFiL0U6XFxNYXl1cl9BY2MwMDhcXGNvZGVcXGZyb250ZW5kXFxtb2JpbGVcXHN0YXIvc3JjXFxhcHBcXHRhYnNcXGhvbWV0YWJcXGhvbWV0YWIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBYTtFQUNiLDhCQUE4QjtFQUM5QixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLFdBQVc7RUFDWCwyQkFBbUI7RUFBbkIsd0JBQW1CO0VBQW5CLG1CQUFtQjtFQUNuQixrQ0FBa0MsRUFBQTs7QUFHcEM7RUFHSSxtQkFBbUIsRUFBQTs7QUFIdkI7SUFNTSxXQUFXO0lBQ1gsYUFBYTtJQUNiLDBCQUEwQixFQUFBOztBQVJoQztJQWdCVSxlQUFlO0lBQ2YsbUJBQW1CLEVBQUE7O0FBakI3QjtJQXdCVSxXQUFXO0lBQ1gscUJBQXFCO0lBQ3JCLGdCQUFnQjtJQUNoQixnQkFBZ0IsRUFBQTs7QUEzQjFCO0lBK0JVLGFBQWE7SUFDYixXQUFXO0lBQ1gsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQiwrQkFBK0IsRUFBQTs7QUFuQ3pDO01Bc0NZLFdBQVc7TUFDWCxZQUFZLEVBQUE7O0FBdkN4QjtRQTBDYyxhQUFhLEVBQUE7O0FBMUMzQjtRQTBDYyxhQUFhLEVBQUE7O0FBMUMzQjtRQTBDYyxhQUFhLEVBQUE7O0FBMUMzQjtRQTBDYyxhQUFhLEVBQUE7O0FBMUMzQjtRQTBDYyxhQUFhLEVBQUE7O0FBMUMzQjtRQThDYyxhQUFhLEVBQUE7O0FBOUMzQjtNQW1EWSxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWJzL2hvbWV0YWIvaG9tZXRhYi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBwYWRkaW5nOiAxMHB4IDIwcHg7XHJcbiAgICBmb250LXNpemU6IDEuMnJlbTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiBmaXQtY29udGVudDtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBnYWluc2Jvcm87XHJcbiAgfVxyXG4gIFxyXG4gIC5wb3N0cyB7XHJcbiAgXHJcbiAgICBpb24tY2FyZCB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgXHJcbiAgICAgIC5pbWFnZSB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAyNTBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBjb3JuZmxvd2VyYmx1ZTtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICBpb24tY2FyZC1jb250ZW50IHtcclxuICBcclxuICAgICAgICAuYnV0dG9ucyB7XHJcbiAgXHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcclxuICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgLmNvbW1lbnQge1xyXG4gIFxyXG4gICAgICAgICAgYSB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xyXG4gICAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICAuYWRkY29tbWVudHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgMTBweDtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuICBcclxuICAgICAgICAgICAgaW5wdXQge1xyXG4gICAgICAgICAgICAgIHdpZHRoOiA4MHZ3O1xyXG4gICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICBcclxuICAgICAgICAgICAgICAmOjpwbGFjZWhvbGRlciB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogc2lsdmVyO1xyXG4gICAgICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgICAgICAmOmZvY3VzIHtcclxuICAgICAgICAgICAgICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgICB3aWR0aDogMjB2dztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gIFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gIFxyXG4gICAgfVxyXG4gIH1cclxuICAiXX0= */"

/***/ }),

/***/ "./src/app/tabs/hometab/hometab.page.ts":
/*!**********************************************!*\
  !*** ./src/app/tabs/hometab/hometab.page.ts ***!
  \**********************************************/
/*! exports provided: HometabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HometabPage", function() { return HometabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HometabPage = /** @class */ (function () {
    function HometabPage() {
    }
    HometabPage.prototype.ngOnInit = function () {
    };
    HometabPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-hometab',
            template: __webpack_require__(/*! ./hometab.page.html */ "./src/app/tabs/hometab/hometab.page.html"),
            styles: [__webpack_require__(/*! ./hometab.page.scss */ "./src/app/tabs/hometab/hometab.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HometabPage);
    return HometabPage;
}());



/***/ })

}]);
//# sourceMappingURL=hometab-hometab-module.js.map